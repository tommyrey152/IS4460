def titleCase(name_list):
    return[name.title() for name in name_list]