#from customer.models get Customer
# python3 manage.py shell
# python3 manage.py makemigrations
# python3 manage.py migrate
#
#
#cust1 = Customer.objects.get(pk=1)
#
#
#
#
#
#
# cust1.delete()
# cust1 = Customer.objects.create(name="Utah State", email="utahstate@utahstate.edu")
#
#
#
#
#oc1 = Customer.objects.get(name = "University of Utah")
#order1 = Order(customer = oc1, total_price = 500, total_items = 2)
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
